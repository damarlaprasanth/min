﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBooking.Models;

namespace OnlineTaxiBooking.Controllers
{
    public class EmployeeRoastersController : Controller
    {
        private Training_20March_CloudChennaiEntities5 db = new Training_20March_CloudChennaiEntities5();

        // GET: EmployeeRoasters
        public ActionResult Index()
        {
            var employeeRoasters = db.EmployeeRoasters.Include(e => e.EmployeeLogin);
            return View(employeeRoasters.ToList());
        }

        // GET: EmployeeRoasters/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeRoaster employeeRoaster = db.EmployeeRoasters.Find(id);
            if (employeeRoaster == null)
            {
                return HttpNotFound();
            }
            return View(employeeRoaster);
        }

        // GET: EmployeeRoasters/Create
        public ActionResult Create()
        {
            ViewBag.Eid = new SelectList(db.EmployeeLogins, "EmployeeId", "EmployeeName");
            return View();
        }

        // POST: EmployeeRoasters/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "RosterId,Eid,FromDate,ToDate,InTime,OutTime")] EmployeeRoaster employeeRoaster)
        {
            if (ModelState.IsValid)
            {
                db.EmployeeRoasters.Add(employeeRoaster);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Eid = new SelectList(db.EmployeeLogins, "EmployeeId", "EmployeeName", employeeRoaster.Eid);
            return View(employeeRoaster);
        }

        // GET: EmployeeRoasters/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeRoaster employeeRoaster = db.EmployeeRoasters.Find(id);
            if (employeeRoaster == null)
            {
                return HttpNotFound();
            }
            ViewBag.Eid = new SelectList(db.EmployeeLogins, "EmployeeId", "EmployeeName", employeeRoaster.Eid);
            return View(employeeRoaster);
        }

        // POST: EmployeeRoasters/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "RosterId,Eid,FromDate,ToDate,InTime,OutTime")] EmployeeRoaster employeeRoaster)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employeeRoaster).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Eid = new SelectList(db.EmployeeLogins, "EmployeeId", "EmployeeName", employeeRoaster.Eid);
            return View(employeeRoaster);
        }

        // GET: EmployeeRoasters/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeRoaster employeeRoaster = db.EmployeeRoasters.Find(id);
            if (employeeRoaster == null)
            {
                return HttpNotFound();
            }
            return View(employeeRoaster);
        }

        // POST: EmployeeRoasters/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EmployeeRoaster employeeRoaster = db.EmployeeRoasters.Find(id);
            db.EmployeeRoasters.Remove(employeeRoaster);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
