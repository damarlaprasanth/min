﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBooking.Models;

namespace OnlineTaxiBooking.Controllers
{
    public class EmployeeController : Controller
    {
        Training_20March_CloudChennaiEntities5 db = new Training_20March_CloudChennaiEntities5();
        // GET: Emploee
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult EmployeeLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult EmployeeLogin(EmployeeLogin login)
        {
            if (ModelState.IsValid)
            {

                var user = (from EmployeeLogin cl in db.EmployeeLogins
                            where cl.EmployeeName == login.EmployeeName && cl.Password == login.Password
                            select new
                            {
                                cl.EmployeeName
                            }).ToList();
                if (user.FirstOrDefault() != null)
                {
                    Session["EmployeeName"] = user.FirstOrDefault().EmployeeName;

                    return Redirect("/Employee/EmployeeRoles");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid login credentials.");
                }
            }
            return View(login);
        }
       
        public ActionResult EmployeeRoles()
        {
            return View();
        }
        public ActionResult Checkbookings()
        {
            List<Booking> b = db.Bookings.ToList();
            return View(b);
        } 
        public ActionResult CheckRoaster()
        {
            List<EmployeeRoaster> Er = db.EmployeeRoasters.ToList();
            return View(Er);
        }
        public ActionResult EmployeeDetails()
        {
            List<EmployeeLogin> li = db.EmployeeLogins.ToList();
            return View(li);
        } 
    }
}