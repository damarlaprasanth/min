﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBooking.Models;

namespace OnlineTaxiBooking.Controllers
{
    public class AdminController : Controller
    {
        Training_20March_CloudChennaiEntities5 obj = new Training_20March_CloudChennaiEntities5();
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(AdminLogin L)
        {
            if (L.UserName == "Admin" && L.Password == "Admin")
            {
                return RedirectToAction("AdminRoles");
            }
            return View();
        }
        [HttpGet]
        public ActionResult AdminRoles()
        {
            return View();
        }
        public ActionResult ChangePassword()
        {
            return View();
        }  
        [HttpGet]
        public ActionResult RegisterRoaster()
        {
            return View();
        }    
        [HttpPost]
        public ActionResult RegisterRoaster(EmployeeRoaster Roaster)
        {
            obj.EmployeeRoasters.Add(Roaster);
            obj.SaveChanges();
            return View();
        }
        [HttpGet]
        public ActionResult RegisterEmployee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult RegisterEmployee(EmployeeLogin Emp)
        {
            obj.EmployeeLogins.Add(Emp);
            obj.SaveChanges();
            return RedirectToAction("RegisteredSuccessfully");
        } 
        public ActionResult RegisteredSuccessfully()
        {
            return View();
        }
        public ActionResult Managesystemusers()
        {
            return View();
        }


        public ActionResult EnmployeFeedBacks()
        {
            List<Feedback> FB = obj.Feedbacks.ToList();
            return View(FB);
        }
        [HttpGet]
        public ActionResult Taxi()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Taxi(Taxi T)
        {
            obj.Taxis.Add(T);
            obj.SaveChanges();
            return RedirectToAction("AdminRoles");
        }
        public ActionResult Logout()
        {
            return RedirectToAction("Index");
        }
    }
}