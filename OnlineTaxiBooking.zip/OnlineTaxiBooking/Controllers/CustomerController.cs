﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBooking.Models;

namespace OnlineTaxiBooking.Controllers
{
    public class CustomerController : Controller
    {
        Training_20March_CloudChennaiEntities5 obj = new Training_20March_CloudChennaiEntities5();
        // GET: Customer
        [HttpGet]
        public ActionResult CustomerRegistration()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CustomerRegistration(CustomerLogin Registration)
        {
            obj.CustomerLogins.Add(Registration);
            obj.SaveChanges();
            return RedirectToAction("Index","Admin");
        }
        public ActionResult CustomerLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CustomerLogin(CustomerLogin Login)
        {
            if (ModelState.IsValid)
            {
                var user = (from CustomerLogin cl in obj.CustomerLogins
                            where cl.CustomerName == Login.CustomerName && cl.Password == Login.Password
                            select new
                            {
                                cl.CustomerName
                            }).ToList();
                if (user.FirstOrDefault() != null)
                {
                    Session["CustomerName"] = user.FirstOrDefault().CustomerName;

                    return Redirect("CustomerRoles");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid login credentials.");
                }
            }
            return View(Login);
        }       
        public ActionResult CustomerRoles()
        {
            return View();
        }
        public ActionResult CustomerDetails()
        {
            List<CustomerLogin> li = obj.CustomerLogins.ToList();
            return View(li);
        }
        [HttpGet]
        public ActionResult FeedBacks()
        {
            return View();
        }
        [HttpPost]
        public ActionResult FeedBacks(Feedback FB)
        {
            obj.Feedbacks.Add(FB);
            obj.SaveChanges();
            return RedirectToAction("CustomerRoles");
        }       
    }
}